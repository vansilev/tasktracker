<?php

return [
    'task_assigned' => 'Task #:number :title assigned to you (:actor)',
    'task_status_changed' => 'Task #:number :title status changed: :old → :new (:actor)',
    'task_commented' => 'New comment on task #:number :title (:actor): :excerpt',
    'task_mentioned' => 'You were mentioned in task #:number :title (:actor): :excerpt',
    'task_deadline_approaching' => 'Task #:number :title deadline approaching (:deadline)',
    'task_overdue' => 'Task #:number :title is overdue (:deadline)',
    'task_review_sla_expired' => 'Review SLA expired for task #:number :title (:review_due_at)',
    'mark_all_read' => 'Mark all as read',
    'no_notifications' => 'No notifications',
    'title' => 'Notifications',
    'preferences_title' => 'Notification preferences',
    'preferences_description' => 'Choose which notifications to receive and through which channels.',
    'event' => 'Event',
    'channels_coming_soon' => 'Email and Telegram channels will be enabled later — delivery is not active yet.',
    'events' => [
        'task_assigned' => 'Task assigned',
        'task_status_changed' => 'Status changed',
        'task_commented' => 'New comment',
        'task_mentioned' => 'Mention (@)',
        'task_deadline_approaching' => 'Deadline approaching',
        'task_overdue' => 'Overdue deadline',
        'task_review_sla_expired' => 'Review SLA expired',
    ],
    'channels' => [
        'database' => 'In-app',
        'email' => 'Email',
        'telegram' => 'Telegram',
    ],
];
