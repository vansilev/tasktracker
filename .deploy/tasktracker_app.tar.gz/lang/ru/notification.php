<?php

return [
    'task_assigned' => 'Вам назначена задача #:number :title (:actor)',
    'task_status_changed' => 'Статус задачи #:number :title изменён: :old → :new (:actor)',
    'task_commented' => 'Новый комментарий к задаче #:number :title (:actor): :excerpt',
    'task_mentioned' => 'Вас упомянули в задаче #:number :title (:actor): :excerpt',
    'task_deadline_approaching' => 'Приближается дедлайн задачи #:number :title (:deadline)',
    'task_overdue' => 'Просрочен дедлайн задачи #:number :title (:deadline)',
    'task_review_sla_expired' => 'Истёк SLA проверки задачи #:number :title (:review_due_at)',
    'mark_all_read' => 'Отметить все прочитанными',
    'no_notifications' => 'Нет уведомлений',
    'title' => 'Уведомления',
    'preferences_title' => 'Настройки уведомлений',
    'preferences_description' => 'Выберите, какие уведомления получать и по каким каналам.',
    'event' => 'Событие',
    'channels_coming_soon' => 'Каналы Email и Telegram будут включены позже — доставка по ним пока не работает.',
    'events' => [
        'task_assigned' => 'Назначение задачи',
        'task_status_changed' => 'Смена статуса',
        'task_commented' => 'Новый комментарий',
        'task_mentioned' => 'Упоминание (@)',
        'task_deadline_approaching' => 'Приближение дедлайна',
        'task_overdue' => 'Просрочен дедлайн',
        'task_review_sla_expired' => 'Истёк SLA проверки',
    ],
    'channels' => [
        'database' => 'In-app',
        'email' => 'Email',
        'telegram' => 'Telegram',
    ],
];
