<?php

return [
    'task_assigned' => 'Вам призначено завдання #:number :title (:actor)',
    'task_status_changed' => 'Статус завдання #:number :title змінено: :old → :new (:actor)',
    'task_commented' => 'Новий коментар до завдання #:number :title (:actor): :excerpt',
    'task_mentioned' => 'Вас згадали у завданні #:number :title (:actor): :excerpt',
    'task_deadline_approaching' => 'Наближається дедлайн завдання #:number :title (:deadline)',
    'task_overdue' => 'Прострочено дедлайн завдання #:number :title (:deadline)',
    'task_review_sla_expired' => 'Минув SLA перевірки завдання #:number :title (:review_due_at)',
    'mark_all_read' => 'Позначити всі прочитаними',
    'no_notifications' => 'Немає сповіщень',
    'title' => 'Сповіщення',
    'preferences_title' => 'Налаштування сповіщень',
    'preferences_description' => 'Оберіть, які сповіщення отримувати та якими каналами.',
    'event' => 'Подія',
    'channels_coming_soon' => 'Канали Email і Telegram будуть увімкнені пізніше — доставка по них поки не працює.',
    'events' => [
        'task_assigned' => 'Призначення завдання',
        'task_status_changed' => 'Зміна статусу',
        'task_commented' => 'Новий коментар',
        'task_mentioned' => 'Згадка (@)',
        'task_deadline_approaching' => 'Наближення дедлайну',
        'task_overdue' => 'Прострочений дедлайн',
        'task_review_sla_expired' => 'Минув SLA перевірки',
    ],
    'channels' => [
        'database' => 'In-app',
        'email' => 'Email',
        'telegram' => 'Telegram',
    ],
];
