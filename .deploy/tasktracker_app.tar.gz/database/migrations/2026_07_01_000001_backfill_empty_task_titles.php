<?php

use App\Models\Task;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        Task::query()
            ->where(function ($query): void {
                $query->where('title', '')->orWhereNull('title');
            })
            ->eachById(function (Task $task): void {
                $normalized = trim(preg_replace('/\s+/', ' ', $task->description ?? '') ?? '');

                $task->update([
                    'title' => Str::limit($normalized, 120, ''),
                ]);
            });
    }

    public function down(): void
    {
        // Irreversible data fix.
    }
};
