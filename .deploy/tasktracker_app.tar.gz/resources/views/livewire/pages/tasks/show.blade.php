<?php

use App\Enums\TaskStatus;
use App\Models\Department;
use App\Models\Task;
use App\Models\TaskAttachment;
use App\Models\TaskChecklistItem;
use App\Models\TaskComment;
use App\Services\TaskHistoryPresenter;
use App\Services\MarkdownService;
use App\Services\MentionService;
use App\Services\SettingsService;
use App\Services\TaskAttachmentService;
use App\Services\TaskService;
use App\Services\TaskWorkflowService;
use Livewire\Attributes\Layout;
use Livewire\Features\SupportFileUploads\WithFileUploads;
use Livewire\Volt\Component;

new #[Layout('components.tasks-layout')] class extends Component
{
    use WithFileUploads;

    public Task $task;
    public string $commentBody = '';
    public bool $editing = false;
    public string $editTitle = '';
    public string $editDescription = '';
    public int $editPriority = 5;
    public ?string $editDeadline = null;
    public string $editSpecUrl = '';
    public string $editResultUrl = '';
    public ?int $editAssigneeId = null;
    public ?int $editAssigneeDepartmentId = null;
    public string $reassignComment = '';
    public string $newChecklistItem = '';
    public ?string $pendingTransition = null;
    public string $transitionComment = '';
    public ?string $transitionError = null;
    public bool $editingWatchers = false;
    public array $watcherIds = [];
    public ?int $editingCommentId = null;
    public string $editCommentBody = '';
    public array $uploadFiles = [];
    public array $commentFiles = [];

    public function mount(Task $task): void
    {
        $this->task = $task->load([
            'initiator', 'assignee', 'department', 'category',
            'comments.author', 'comments.mentionedUsers', 'comments.attachments',
            'histories.changedBy',
            'checklistItems', 'watchers', 'attachments.uploader',
        ]);

        abort_unless(auth()->user()->can('view', $this->task), 403);

        $this->editTitle = $this->task->title;
        $this->editDescription = $this->task->description;
        $this->editPriority = $this->task->priority;
        $this->editDeadline = $this->task->deadline?->format('Y-m-d');
        $this->editSpecUrl = $this->task->spec_url ?? '';
        $this->editResultUrl = $this->task->result_url ?? '';
        $this->editAssigneeId = $this->task->assignee_id;
        $this->editAssigneeDepartmentId = $this->task->department_id;
    }

    public function updatedEditAssigneeDepartmentId(): void
    {
        $this->editAssigneeId = null;
    }

    public function with(): array
    {
        return [
            'transitions' => app(TaskWorkflowService::class)->allowedTransitions(auth()->user(), $this->task),
            'assignees' => \App\Models\User::query()
                ->where('is_active', true)
                ->where('department_id', $this->editAssigneeDepartmentId ?? $this->task->department_id)
                ->orderBy('name')
                ->get(['id', 'name']),
            'departments' => Department::query()->active()->orderBy('name')->get(['id', 'name']),
            'checklistDone' => $this->task->checklistItems->where('is_done', true)->count(),
            'checklistTotal' => $this->task->checklistItems->count(),
            'canManageWatchers' => auth()->user()->can('manageWatchers', $this->task),
            'canUpdate' => auth()->user()->can('update', $this->task),
            'canChangePriority' => auth()->user()->can('changePriority', $this->task),
            'canAssign' => auth()->user()->can('assign', $this->task),
            'canComment' => auth()->user()->can('comment', $this->task),
            'canManageChecklist' => auth()->user()->can('manageChecklist', $this->task),
            'canToggleChecklist' => auth()->user()->can('toggleChecklist', $this->task),
            'canUploadAttachment' => auth()->user()->can('uploadAttachment', $this->task),
            'markdown' => app(MarkdownService::class),
            'allUsers' => \App\Models\User::query()
                ->where('is_active', true)
                ->orderBy('name')
                ->get(['id', 'name']),
            'presentedHistories' => app(TaskHistoryPresenter::class)->presentMany($this->task->histories),
        ];
    }

    public function startEditWatchers(): void
    {
        abort_unless(auth()->user()->can('manageWatchers', $this->task), 403);
        $this->watcherIds = $this->task->watchers->pluck('id')->map(fn ($v) => (string) $v)->all();
        $this->editingWatchers = true;
    }

    public function saveWatchers(): void
    {
        abort_unless(auth()->user()->can('manageWatchers', $this->task), 403);
        $this->task->watchers()->sync($this->watcherIds);
        $this->task->load('watchers');
        $this->editingWatchers = false;
    }

    public function cancelEditWatchers(): void
    {
        $this->editingWatchers = false;
        $this->watcherIds = [];
    }

    public function removeWatcher(int $userId): void
    {
        abort_unless(auth()->user()->can('manageWatchers', $this->task), 403);
        $this->task->watchers()->detach($userId);
        $this->task->load('watchers');
    }

    public function transitionLabel(TaskStatus $status): string
    {
        if ($this->task->status === TaskStatus::Completed && $status === TaskStatus::InProgress) {
            return __('task.reopen');
        }

        return $status->label();
    }

    public function selectTransition(string $status): void
    {
        $target = TaskStatus::from($status);
        $this->transitionError = null;

        if (TaskStatus::requiresComment($target, $this->task->status)) {
            $this->pendingTransition = $status;
            $this->transitionComment = '';

            return;
        }

        $this->performTransition($status);
    }

    public function confirmTransition(TaskWorkflowService $workflow): void
    {
        $this->validate([
            'transitionComment' => 'required|string|min:1',
        ], [], [
            'transitionComment' => __('Transition comment'),
        ]);

        $this->performTransition($this->pendingTransition, $this->transitionComment);
    }

    public function cancelTransition(): void
    {
        $this->pendingTransition = null;
        $this->transitionComment = '';
        $this->transitionError = null;
    }

    private function performTransition(?string $status, ?string $comment = null): void
    {
        if ($status === null) {
            return;
        }

        try {
            app(TaskWorkflowService::class)->transition(
                $this->task,
                auth()->user(),
                TaskStatus::from($status),
                $comment,
            );

            $this->pendingTransition = null;
            $this->transitionComment = '';
            $this->transitionError = null;
        } catch (\InvalidArgumentException $e) {
            $this->transitionError = $e->getMessage();
        }

        $this->task->refresh()->load([
            'initiator', 'assignee', 'department', 'category',
            'comments.author', 'comments.attachments', 'histories.changedBy', 'checklistItems', 'watchers',
        ]);
    }

    public function addComment(TaskService $tasks, TaskAttachmentService $attachments, SettingsService $settings): void
    {
        $this->validate([
            'commentBody' => 'required|string|min:1',
            'commentFiles.*' => 'nullable|file|max:'.(int) $settings->get('attachment_max_kb', 10240),
        ]);

        $comment = $tasks->addComment($this->task, auth()->user(), $this->commentBody);

        foreach ($this->commentFiles as $file) {
            $attachments->store($this->task, auth()->user(), $file, $comment->id);
        }

        $this->commentBody = '';
        $this->commentFiles = [];
        $this->task->load(['comments.author', 'comments.mentionedUsers', 'comments.attachments']);
    }

    public function saveEdit(TaskService $tasks): void
    {
        abort_unless(auth()->user()->can('update', $this->task), 403);

        $assigneeChanging = auth()->user()->can('assign', $this->task)
            && $this->editAssigneeId !== null
            && (int) $this->editAssigneeId !== (int) $this->task->assignee_id;

        $rules = [
            'editTitle' => 'required|string|max:120',
            'editDescription' => 'required|string|min:3',
            'editPriority' => 'integer|min:1|max:10',
            'editDeadline' => 'nullable|date',
            'editSpecUrl' => 'nullable|url|max:500',
            'editResultUrl' => 'nullable|url|max:500',
        ];

        if ($assigneeChanging) {
            $rules['reassignComment'] = 'required|string|min:1';
        }

        $this->validate($rules, [], [
            'reassignComment' => __('Reassignment comment'),
        ]);

        $data = [
            'title' => $this->editTitle,
            'description' => $this->editDescription,
            'deadline' => $this->editDeadline,
            'spec_url' => $this->editSpecUrl ?: null,
            'result_url' => $this->editResultUrl ?: null,
        ];

        if (auth()->user()->can('changePriority', $this->task)) {
            $data['priority'] = $this->editPriority;
        }

        if (auth()->user()->can('assign', $this->task)) {
            $data['assignee_id'] = $this->editAssigneeId;
        }

        $tasks->update($this->task, auth()->user(), $data);

        if ($assigneeChanging) {
            $tasks->addComment($this->task, auth()->user(), $this->reassignComment);
            $this->reassignComment = '';
        }

        $this->task->refresh()->load([
            'initiator', 'assignee', 'department', 'category',
            'comments.author', 'comments.mentionedUsers', 'comments.attachments',
        ]);
        $this->editAssigneeDepartmentId = $this->task->department_id;
        $this->editAssigneeId = $this->task->assignee_id;
        $this->editing = false;
    }

    public function toggleChecklist(int $itemId, TaskService $tasks): void
    {
        $item = TaskChecklistItem::query()->where('task_id', $this->task->id)->findOrFail($itemId);
        $tasks->toggleChecklistItem($item, auth()->user());
        $this->task->load('checklistItems');
    }

    public function addChecklistItem(TaskService $tasks): void
    {
        $text = trim($this->newChecklistItem);
        if ($text === '') {
            return;
        }

        $tasks->addChecklistItem($this->task, auth()->user(), $text);
        $this->newChecklistItem = '';
        $this->task->load('checklistItems');
    }

    public function deleteChecklistItem(int $itemId, TaskService $tasks): void
    {
        $item = TaskChecklistItem::query()->where('task_id', $this->task->id)->findOrFail($itemId);
        $tasks->deleteChecklistItem($item, auth()->user());
        $this->task->load('checklistItems');
    }

    public function startEditComment(int $commentId): void
    {
        $comment = TaskComment::query()->where('task_id', $this->task->id)->findOrFail($commentId);
        abort_unless($comment->canBeEditedBy(auth()->user()), 403);
        $this->editingCommentId = $comment->id;
        $this->editCommentBody = $comment->body;
    }

    public function saveCommentEdit(TaskService $tasks): void
    {
        $comment = TaskComment::query()->where('task_id', $this->task->id)->findOrFail($this->editingCommentId);
        $tasks->updateComment($comment, auth()->user(), $this->editCommentBody);
        $this->editingCommentId = null;
        $this->editCommentBody = '';
        $this->task->load(['comments.author', 'comments.mentionedUsers']);
    }

    public function deleteComment(int $commentId, TaskService $tasks): void
    {
        $comment = TaskComment::query()->where('task_id', $this->task->id)->findOrFail($commentId);
        $tasks->deleteComment($comment, auth()->user());
        $this->task->load(['comments.author', 'comments.mentionedUsers']);
    }

    public function uploadAttachment(TaskAttachmentService $attachments, SettingsService $settings): void
    {
        $this->validate([
            'uploadFiles' => 'required|array|min:1',
            'uploadFiles.*' => 'file|max:'.(int) $settings->get('attachment_max_kb', 10240),
        ]);

        foreach ($this->uploadFiles as $file) {
            $attachments->store($this->task, auth()->user(), $file);
        }

        $this->uploadFiles = [];
        $this->task->load('attachments.uploader');
    }

    public function deleteAttachment(int $attachmentId, TaskAttachmentService $attachments): void
    {
        $attachment = TaskAttachment::query()
            ->where('task_id', $this->task->id)
            ->findOrFail($attachmentId);

        $attachments->delete($attachment, auth()->user());

        $this->task->load(['attachments.uploader', 'comments.attachments', 'histories.changedBy']);
    }

    /** @return list<array{id: int, name: string, email: string, token: string}> */
    public function mentionSearch(string $term): array
    {
        return app(MentionService::class)->searchMentionableUsers($term);
    }

    public function initials(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name)) ?: [];
        $initials = '';
        foreach (array_slice($parts, 0, 2) as $part) {
            $initials .= mb_strtoupper(mb_substr($part, 0, 1));
        }

        return $initials ?: '?';
    }

    /** @return array{text: string, class: string} */
    public function deadlineMeta(): array
    {
        if ($this->task->deadline === null) {
            return ['text' => '—', 'class' => 'text-gray-700'];
        }

        $deadline = $this->task->deadline->timezone(config('app.timezone'));
        $formatted = $deadline->format('d.m.Y');

        if (! $this->task->status->isOpen()) {
            return ['text' => $formatted, 'class' => 'text-gray-700'];
        }

        $now = now()->timezone(config('app.timezone'));

        if ($deadline->isPast()) {
            $days = (int) $deadline->diffInDays($now);

            return [
                'text' => __(':date (overdue :count days)', ['date' => $formatted, 'count' => $days]),
                'class' => 'text-red-600 font-medium',
            ];
        }

        if ((int) $now->diffInDays($deadline) <= 3) {
            return [
                'text' => $deadline->diffForHumans(),
                'class' => 'text-amber-600 font-medium',
            ];
        }

        return ['text' => $formatted, 'class' => 'text-gray-700'];
    }
}; ?>

<div class="space-y-4">
    <div class="flex items-center justify-between gap-4">
        <a href="{{ route('tasks.index') }}" wire:navigate class="inline-flex items-center gap-1 text-sm font-medium text-indigo-600 hover:text-indigo-800 transition-colors">
            <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
            {{ __('Back to tasks') }}
        </a>
    </div>

    @if (session('status'))
        <div class="rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 text-sm">{{ session('status') }}</div>
    @endif

    {{-- Header --}}
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <div class="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
            <div class="min-w-0">
                <div class="flex flex-wrap items-center gap-2">
                    <h1 class="text-lg font-semibold text-gray-900">
                        #{{ $task->number }} · {{ $task->title }}
                    </h1>
                    <x-status-badge :status="$task->status" />
                    @if ($task->priority >= 9)
                        <span title="{{ __('Urgent') }}">🔥</span>
                    @endif
                </div>
            </div>
            <div class="flex flex-wrap items-center gap-1.5 shrink-0">
                @if ($canUpdate && ! $editing)
                    <x-action-button variant="ghost" wire:click="$set('editing', true)">
                        <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
                        {{ __('Edit') }}
                    </x-action-button>
                @endif
                @if (! $pendingTransition)
                    @foreach ($transitions as $transition)
                        @php
                            $isDestructive = in_array($transition, [\App\Enums\TaskStatus::Cancelled, \App\Enums\TaskStatus::Rejected], true);
                            $isPositive = in_array($transition, [\App\Enums\TaskStatus::Completed, \App\Enums\TaskStatus::InProgress], true);
                            $variant = $isDestructive ? 'danger' : ($isPositive ? 'primary' : 'secondary');
                        @endphp
                        <x-action-button :variant="$variant" wire:click="selectTransition('{{ $transition->value }}')">
                            {{ $this->transitionLabel($transition) }}
                        </x-action-button>
                    @endforeach
                @endif
            </div>
        </div>
    </div>

    @if ($transitionError)
        <div class="rounded-lg bg-red-50 border border-red-200 text-red-700 px-4 py-2 text-sm">{{ $transitionError }}</div>
    @endif

    @if ($pendingTransition)
        <div class="rounded-xl bg-amber-50 border border-amber-200 p-4 space-y-3">
            <p class="text-sm font-medium text-amber-900">{{ __('Add a comment for this status change') }}</p>
            <textarea wire:model="transitionComment" rows="3"
                      class="w-full border-amber-200 rounded-lg shadow-sm text-sm focus:border-indigo-500 focus:ring-indigo-500"
                      placeholder="{{ __('task.transition_comment_placeholder') }}"></textarea>
            <x-input-error :messages="$errors->get('transitionComment')" class="mt-1" />
            <div class="flex flex-wrap gap-2">
                <x-action-button variant="primary" wire:click="confirmTransition">
                    {{ __('task.confirm_transition') }}: {{ $this->transitionLabel(\App\Enums\TaskStatus::from($pendingTransition)) }}
                </x-action-button>
                <x-action-button variant="secondary" wire:click="cancelTransition">
                    {{ __('task.cancel_transition') }}
                </x-action-button>
            </div>
        </div>
    @endif

    @if ($editing)
        <x-card>
            <x-slot name="header">
                <h2 class="text-sm font-semibold text-gray-900">{{ __('Edit') }}</h2>
            </x-slot>
            <form wire:submit="saveEdit" class="space-y-4 max-w-3xl">
                <div>
                    <x-input-label :value="__('Title')" />
                    <x-text-input wire:model="editTitle" class="mt-1 w-full" maxlength="120" />
                </div>
                <div>
                    <x-input-label :value="__('Description')" />
                    <textarea wire:model="editDescription" rows="4" class="mt-1 w-full border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-indigo-500"></textarea>
                </div>
                @if ($canChangePriority)
                <div>
                    <x-input-label :value="__('Priority')" />
                    <input type="range" wire:model.live="editPriority" min="1" max="10" class="mt-2 w-full accent-indigo-600" />
                    <x-priority-bar :priority="$editPriority" class="mt-2" size="lg" />
                </div>
                @endif
                <div>
                    <x-input-label :value="__('Deadline')" />
                    <x-text-input type="date" wire:model="editDeadline" class="mt-1 w-full" />
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <x-input-label :value="__('Spec URL')" />
                        <x-text-input wire:model="editSpecUrl" class="mt-1 w-full" />
                    </div>
                    <div>
                        <x-input-label :value="__('Result URL')" />
                        <x-text-input wire:model="editResultUrl" class="mt-1 w-full" />
                    </div>
                </div>
                @if ($canAssign)
                    <div>
                        <x-input-label :value="__('Department')" />
                        <select wire:model.live="editAssigneeDepartmentId" class="mt-1 w-full border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            @foreach ($departments as $dept)
                                <option value="{{ $dept->id }}">{{ $dept->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <x-input-label :value="__('Assignee')" />
                        <select wire:model="editAssigneeId" class="mt-1 w-full border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            @foreach ($assignees as $u)
                                <option value="{{ $u->id }}">{{ $u->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    @if ($editAssigneeId && (int) $editAssigneeId !== (int) $task->assignee_id)
                        <div>
                            <x-input-label :value="__('Reassignment comment')" />
                            <textarea wire:model="reassignComment" rows="2"
                                      class="mt-1 w-full border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                                      placeholder="{{ __('Explain why the task is reassigned') }}"></textarea>
                            <x-input-error :messages="$errors->get('reassignComment')" class="mt-1" />
                        </div>
                    @endif
                @endif
                <div class="flex gap-3">
                    <x-primary-button>{{ __('Save') }}</x-primary-button>
                    <x-secondary-button type="button" wire:click="$set('editing', false)">{{ __('Cancel') }}</x-secondary-button>
                </div>
            </form>
        </x-card>
    @else
        <div class="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4">
            {{-- Left column --}}
            <div class="space-y-4 min-w-0">
                <x-card>
                    <x-slot name="header">
                        <h2 class="text-sm font-semibold text-gray-900">{{ __('Description') }}</h2>
                    </x-slot>
                    <div class="prose prose-sm max-w-none text-gray-800">
                        {!! $markdown->toHtml($task->description) !!}
                    </div>
                </x-card>

                <x-card>
                    <x-slot name="header">
                        <h2 class="text-sm font-semibold text-gray-900">{{ __('Checklist') }}</h2>
                    </x-slot>
                    @if ($checklistTotal > 0)
                        <x-slot name="actions">
                            <span class="text-xs text-gray-500">{{ $checklistDone }}/{{ $checklistTotal }}</span>
                        </x-slot>
                    @endif
                    @if ($checklistTotal > 0)
                        <div class="mb-4 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div class="h-full bg-indigo-500 rounded-full transition-all" style="width: {{ round(($checklistDone / $checklistTotal) * 100) }}%"></div>
                        </div>
                    @endif
                    <ul class="space-y-1.5">
                        @forelse ($task->checklistItems as $item)
                            <li class="flex items-start gap-2 p-1.5 rounded-lg hover:bg-gray-50 transition-colors">
                                @if ($canToggleChecklist)
                                    <input type="checkbox" wire:click="toggleChecklist({{ $item->id }})" @checked($item->is_done)
                                           class="mt-0.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500" />
                                @else
                                    <input type="checkbox" disabled @checked($item->is_done)
                                           class="mt-0.5 rounded border-gray-300 text-gray-400" />
                                @endif
                                <span class="flex-1 text-sm {{ $item->is_done ? 'line-through text-gray-400' : 'text-gray-800' }}">{{ $item->text }}</span>
                                @if ($canManageChecklist)
                                    <button type="button" wire:click="deleteChecklistItem({{ $item->id }})" class="text-xs text-red-600 hover:text-red-800">✕</button>
                                @endif
                            </li>
                        @empty
                            <p class="text-sm text-gray-500 py-2 text-center">{{ __('No checklist items yet.') }}</p>
                        @endforelse
                    </ul>
                    @if ($canManageChecklist)
                    <div class="mt-3 flex gap-2">
                        <x-text-input wire:model="newChecklistItem" class="flex-1" placeholder="{{ __('Add checklist item') }}" wire:keydown.enter="addChecklistItem" />
                        <x-secondary-button type="button" wire:click="addChecklistItem">{{ __('Add') }}</x-secondary-button>
                    </div>
                    @endif
                </x-card>

                <x-card class="flex flex-col">
                    <x-slot name="header">
                        <h2 class="text-sm font-semibold text-gray-900">{{ __('Comments') }}</h2>
                    </x-slot>
                    <div class="space-y-4 max-h-96 overflow-y-auto mb-4 pr-1">
                        @forelse ($task->comments as $comment)
                            <div class="flex gap-2.5">
                                <div class="shrink-0 w-7 h-7 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-[10px] font-semibold">
                                    {{ $this->initials($comment->author->name) }}
                                </div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-xs text-gray-500">
                                        <span class="font-medium text-gray-700">{{ $comment->author->name }}</span>
                                        · {{ $comment->created_at->format('d.m.Y H:i') }}
                                        @if ($comment->edited_at)
                                            <span class="text-gray-400">({{ __('task.edited') }})</span>
                                        @endif
                                    </p>
                                    @if ($editingCommentId === $comment->id)
                                        <form wire:submit="saveCommentEdit" class="mt-2 space-y-2">
                                            <div class="relative" x-data="mentionAutocomplete($wire, 'editCommentBody')">
                                                <textarea x-ref="textarea" wire:model="editCommentBody" rows="2"
                                                          @input="onInput()" @keydown="onKeydown($event)" @blur="onBlur()"
                                                          class="w-full border-gray-300 rounded-lg text-sm"></textarea>
                                                <ul x-show="open" x-cloak
                                                    class="absolute z-20 left-0 right-0 mt-1 max-h-48 overflow-y-auto rounded-lg border border-gray-200 bg-white shadow-lg text-sm">
                                                    <template x-for="(item, index) in suggestions" :key="item.id">
                                                        <li>
                                                            <button type="button"
                                                                    @mousedown.prevent="selectSuggestion(index)"
                                                                    class="w-full px-3 py-2 text-left hover:bg-indigo-50"
                                                                    :class="index === activeIndex ? 'bg-indigo-50' : ''">
                                                                <span class="font-medium text-gray-900" x-text="item.name"></span>
                                                                <span class="ml-2 text-gray-500 text-xs" x-text="item.email"></span>
                                                            </button>
                                                        </li>
                                                    </template>
                                                </ul>
                                            </div>
                                            <div class="flex gap-2">
                                                <x-primary-button type="submit">{{ __('Save') }}</x-primary-button>
                                                <x-secondary-button type="button" wire:click="$set('editingCommentId', null)">{{ __('Cancel') }}</x-secondary-button>
                                            </div>
                                        </form>
                                    @else
                                        <div class="prose prose-sm max-w-none text-gray-800 mt-1">{!! $markdown->toHtml($comment->body) !!}</div>
                                        @if ($comment->attachments->isNotEmpty())
                                            <ul class="mt-2 space-y-1">
                                                @foreach ($comment->attachments as $attachment)
                                                    <li class="flex items-center justify-between gap-2 text-xs">
                                                        <a href="{{ route('tasks.attachments.download', $attachment) }}" class="text-indigo-600 hover:text-indigo-800 hover:underline truncate">
                                                            {{ $attachment->filename }}
                                                        </a>
                                                        <div class="flex items-center gap-2 shrink-0">
                                                            <span class="text-gray-400">{{ number_format($attachment->size / 1024, 1) }} KB</span>
                                                            @can('deleteAttachment', [$task, $attachment])
                                                                <button type="button" wire:click="deleteAttachment({{ $attachment->id }})" wire:confirm="{{ __('Delete this attachment?') }}" class="text-red-600 hover:text-red-800">✕</button>
                                                            @endcan
                                                        </div>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        @endif
                                        @if ($comment->canBeEditedBy(auth()->user()))
                                            <div class="mt-1 flex gap-2">
                                                <button type="button" wire:click="startEditComment({{ $comment->id }})" class="text-xs text-indigo-600 hover:text-indigo-800">{{ __('Edit') }}</button>
                                                <button type="button" wire:click="deleteComment({{ $comment->id }})" wire:confirm="{{ __('Delete this comment?') }}" class="text-xs text-red-600 hover:text-red-800">{{ __('Delete') }}</button>
                                            </div>
                                        @endif
                                    @endif
                                </div>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500 text-center py-6">{{ __('No comments yet.') }}</p>
                        @endforelse
                    </div>
                    @if ($canComment)
                    <form wire:submit="addComment" class="pt-4 border-t border-gray-100 space-y-2">
                        <div class="relative" x-data="mentionAutocomplete($wire, 'commentBody')">
                            <textarea x-ref="textarea" wire:model="commentBody" rows="2"
                                      @input="onInput()" @keydown="onKeydown($event)" @blur="onBlur()"
                                      class="w-full border-gray-300 rounded-lg shadow-sm text-sm focus:border-indigo-500 focus:ring-indigo-500"
                                      placeholder="{{ __('Write a comment...') }} (@username)"></textarea>
                            <ul x-show="open" x-cloak
                                class="absolute z-20 left-0 right-0 mt-1 max-h-48 overflow-y-auto rounded-lg border border-gray-200 bg-white shadow-lg text-sm">
                                <template x-for="(item, index) in suggestions" :key="item.id">
                                    <li>
                                        <button type="button"
                                                @mousedown.prevent="selectSuggestion(index)"
                                                class="w-full px-3 py-2 text-left hover:bg-indigo-50"
                                                :class="index === activeIndex ? 'bg-indigo-50' : ''">
                                            <span class="font-medium text-gray-900" x-text="item.name"></span>
                                            <span class="ml-2 text-gray-500 text-xs" x-text="item.email"></span>
                                        </button>
                                    </li>
                                </template>
                            </ul>
                        </div>
                        <div class="flex flex-wrap items-end gap-2">
                            <input type="file" wire:model="commentFiles" multiple class="text-sm flex-1 min-w-[12rem]" />
                            <x-primary-button class="self-end">{{ __('Send') }}</x-primary-button>
                        </div>
                        <x-input-error :messages="$errors->get('commentFiles.*')" class="mt-1" />
                    </form>
                    @endif
                </x-card>
            </div>

            {{-- Right sidebar --}}
            <aside class="space-y-4 lg:sticky lg:top-6 self-start">
                @php $deadline = $this->deadlineMeta(); @endphp
                <x-card>
                    <x-slot name="header">
                        <h2 class="text-sm font-semibold text-gray-900">{{ __('Meta') }}</h2>
                    </x-slot>
                    <dl class="space-y-3">
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Status') }}</dt>
                            <dd class="mt-0.5"><x-status-badge :status="$task->status" /></dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Priority') }}</dt>
                            <dd class="mt-0.5"><x-priority-bar :priority="$task->priority" /></dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Assignee') }}</dt>
                            <dd class="text-sm text-gray-700">{{ $task->assignee->name }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Initiator') }}</dt>
                            <dd class="text-sm text-gray-700">{{ $task->initiator->name }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Department') }}</dt>
                            <dd class="text-sm text-gray-700">{{ $task->department->name }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Category') }}</dt>
                            <dd class="text-sm text-gray-700">{{ $task->category->name }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Deadline') }}</dt>
                            <dd class="text-sm {{ $deadline['class'] }}">{{ $deadline['text'] }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Created at') }}</dt>
                            <dd class="text-sm text-gray-700">{{ $task->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i') }}</dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Spec URL') }}</dt>
                            <dd class="text-sm">
                                @if ($task->spec_url)
                                    <a href="{{ $task->spec_url }}" target="_blank" class="text-indigo-600 hover:text-indigo-800 hover:underline">{{ __('Open') }}</a>
                                @else
                                    <span class="text-gray-400">—</span>
                                @endif
                            </dd>
                        </div>
                        <div>
                            <dt class="text-xs text-gray-500">{{ __('Result URL') }}</dt>
                            <dd class="text-sm">
                                @if ($task->result_url)
                                    <a href="{{ $task->result_url }}" target="_blank" class="text-indigo-600 hover:text-indigo-800 hover:underline">{{ __('Open') }}</a>
                                @else
                                    <span class="text-gray-400">—</span>
                                @endif
                            </dd>
                        </div>
                    </dl>
                </x-card>

                <x-card>
                    <x-slot name="header">
                        <h2 class="text-sm font-semibold text-gray-900">{{ __('Watchers') }}</h2>
                    </x-slot>
                    @if ($canManageWatchers && ! $editingWatchers)
                        <x-slot name="actions">
                            <x-action-button variant="ghost" wire:click="startEditWatchers">
                                {{ __('Manage watchers') }}
                            </x-action-button>
                        </x-slot>
                    @endif
                    @if ($editingWatchers)
                        <div class="space-y-3">
                            <select wire:model="watcherIds" multiple
                                    class="w-full border-gray-300 rounded-lg shadow-sm h-32 text-sm focus:border-indigo-500 focus:ring-indigo-500">
                                @foreach ($allUsers as $u)
                                    <option value="{{ $u->id }}">{{ $u->name }}</option>
                                @endforeach
                            </select>
                            <div class="flex gap-2">
                                <x-primary-button type="button" wire:click="saveWatchers">{{ __('Save') }}</x-primary-button>
                                <x-secondary-button type="button" wire:click="cancelEditWatchers">{{ __('Cancel') }}</x-secondary-button>
                            </div>
                        </div>
                    @else
                        @if ($task->watchers->isEmpty())
                            <p class="text-sm text-gray-400">{{ __('No watchers yet.') }}</p>
                        @else
                            <ul class="space-y-2">
                                @foreach ($task->watchers as $watcher)
                                    <li class="flex items-center gap-2 text-sm text-gray-700">
                                        <span class="w-6 h-6 shrink-0 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-[10px] font-semibold">{{ $this->initials($watcher->name) }}</span>
                                        <span class="flex-1 min-w-0 truncate">{{ $watcher->name }}</span>
                                        @if ($canManageWatchers)
                                            <button type="button" wire:click="removeWatcher({{ $watcher->id }})" class="w-4 h-4 shrink-0 flex items-center justify-center text-gray-400 hover:text-red-600">✕</button>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    @endif
                </x-card>

                <x-card>
                    <x-slot name="header">
                        <h2 class="text-sm font-semibold text-gray-900">{{ __('Attachments') }}</h2>
                    </x-slot>
                    <ul class="space-y-1.5 mb-3">
                        @forelse ($task->attachments->whereNull('comment_id') as $attachment)
                            <li class="flex items-center justify-between gap-2 text-sm">
                                <a href="{{ route('tasks.attachments.download', $attachment) }}" class="text-indigo-600 hover:text-indigo-800 hover:underline truncate min-w-0">
                                    {{ $attachment->filename }}
                                </a>
                                <div class="flex items-center gap-1.5 shrink-0">
                                    <span class="text-gray-400 text-xs">{{ number_format($attachment->size / 1024, 1) }} KB</span>
                                    @can('deleteAttachment', [$task, $attachment])
                                        <button type="button" wire:click="deleteAttachment({{ $attachment->id }})" wire:confirm="{{ __('Delete this attachment?') }}" class="text-xs text-red-600 hover:text-red-800">✕</button>
                                    @endcan
                                </div>
                            </li>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No attachments yet.') }}</p>
                        @endforelse
                    </ul>
                    @if ($canUploadAttachment)
                        <form wire:submit="uploadAttachment" class="flex flex-col gap-2">
                            <input type="file" wire:model="uploadFiles" multiple class="text-xs w-full" />
                            <x-secondary-button type="submit" wire:loading.attr="disabled" class="self-start">{{ __('Upload') }}</x-secondary-button>
                        </form>
                        <x-input-error :messages="$errors->get('uploadFiles')" class="mt-1" />
                        <x-input-error :messages="$errors->get('uploadFiles.*')" class="mt-1" />
                    @endif
                </x-card>
            </aside>
        </div>
    @endif

    {{-- History (collapsed by default) --}}
    <x-card padding="p-0" x-data="{ open: false }">
        <button type="button" @click="open = !open"
                class="w-full flex items-center justify-between gap-2 px-5 py-4 text-left hover:bg-gray-50/80 transition-colors rounded-xl">
            <h2 class="text-sm font-semibold text-gray-900">{{ __('History') }} ({{ count($presentedHistories) }})</h2>
            <svg class="w-4 h-4 shrink-0 text-gray-500 transition-transform" :class="open ? 'rotate-180' : ''"
                 fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
            </svg>
        </button>
        <div x-show="open" x-collapse class="px-5 pb-5 border-t border-gray-100">
            <ul class="space-y-0 pt-4">
                @forelse ($presentedHistories as $presented)
                    @php $entry = $presented['entry']; @endphp
                    <li class="relative pl-6 pb-4 last:pb-0 border-l-2 border-indigo-100 last:border-transparent ml-2">
                        <span class="absolute -left-[5px] top-1.5 w-2 h-2 rounded-full bg-indigo-400"></span>
                        <p class="text-sm text-gray-800">
                            <span class="text-gray-400 text-xs">{{ $entry->created_at->format('d.m.Y H:i') }}</span>
                            <span class="mx-1">·</span>
                            <span class="font-medium">{{ $entry->changedBy->name }}</span>
                            <span class="text-gray-500">— {{ $presented['field'] }}</span>
                        </p>
                        <p class="text-xs text-gray-500 mt-0.5">{{ $presented['old'] ?? '—' }} → {{ $presented['new'] ?? '—' }}</p>
                    </li>
                @empty
                    <li class="text-sm text-gray-500 text-center py-4">{{ __('No history yet.') }}</li>
                @endforelse
            </ul>
        </div>
    </x-card>
</div>

@script
<script>
    Alpine.data('mentionAutocomplete', (wire, property) => ({
        open: false,
        suggestions: [],
        activeIndex: 0,
        debounceTimer: null,
        mentionStart: -1,
        mentionEnd: -1,

        getMentionContext() {
            const textarea = this.$refs.textarea;
            if (!textarea) {
                return null;
            }

            const pos = textarea.selectionStart ?? textarea.value.length;
            const text = textarea.value.substring(0, pos);
            const match = text.match(/@([\p{L}\p{N}._-]+)$/u);

            if (!match || match[1].length < 1) {
                return null;
            }

            return {
                query: match[1],
                start: pos - match[0].length,
                end: pos,
            };
        },

        onInput() {
            const ctx = this.getMentionContext();
            if (!ctx) {
                this.close();
                return;
            }

            this.mentionStart = ctx.start;
            this.mentionEnd = ctx.end;
            clearTimeout(this.debounceTimer);
            this.debounceTimer = setTimeout(() => this.search(ctx.query), 250);
        },

        async search(query) {
            const ctx = this.getMentionContext();
            if (!ctx || ctx.query !== query) {
                return;
            }

            try {
                const results = await wire.mentionSearch(query);
                if (!this.getMentionContext()) {
                    this.close();
                    return;
                }

                this.suggestions = results ?? [];
                this.activeIndex = 0;
                this.open = this.suggestions.length > 0;
            } catch {
                this.close();
            }
        },

        onKeydown(event) {
            if (!this.open) {
                return;
            }

            if (event.key === 'ArrowDown') {
                event.preventDefault();
                this.activeIndex = Math.min(this.activeIndex + 1, this.suggestions.length - 1);
            } else if (event.key === 'ArrowUp') {
                event.preventDefault();
                this.activeIndex = Math.max(this.activeIndex - 1, 0);
            } else if (event.key === 'Enter' && this.suggestions.length > 0) {
                event.preventDefault();
                this.selectSuggestion(this.activeIndex);
            } else if (event.key === 'Escape') {
                event.preventDefault();
                this.close();
            }
        },

        selectSuggestion(index) {
            const item = this.suggestions[index];
            if (!item) {
                return;
            }

            const textarea = this.$refs.textarea;
            const value = textarea.value;
            const before = value.substring(0, this.mentionStart);
            const after = value.substring(this.mentionEnd);
            const insertion = '@' + item.token + ' ';
            const newValue = before + insertion + after;
            const cursorPos = before.length + insertion.length;

            textarea.value = newValue;
            wire.set(property, newValue);
            textarea.setSelectionRange(cursorPos, cursorPos);
            textarea.focus();
            this.close();
        },

        close() {
            this.open = false;
            this.suggestions = [];
            this.activeIndex = 0;
        },

        onBlur() {
            setTimeout(() => this.close(), 200);
        },
    }));
</script>
@endscript
