<?php

use App\Models\AuditLog;
use App\Models\User;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Url;
use Livewire\Volt\Component;
use Livewire\WithPagination;

new #[Layout('components.admin-layout')] class extends Component
{
    use WithPagination;

    #[Url]
    public string $filterAction = '';

    #[Url]
    public string $filterActorId = '';

    #[Url]
    public string $filterDateFrom = '';

    #[Url]
    public string $filterDateTo = '';

    public function updatedFilterAction(): void
    {
        $this->resetPage();
    }

    public function updatedFilterActorId(): void
    {
        $this->resetPage();
    }

    public function updatedFilterDateFrom(): void
    {
        $this->resetPage();
    }

    public function updatedFilterDateTo(): void
    {
        $this->resetPage();
    }

    public function with(): array
    {
        $query = AuditLog::query()
            ->with('actor')
            ->orderByDesc('created_at');

        if ($this->filterAction !== '') {
            $query->where('action', $this->filterAction);
        }

        if ($this->filterActorId !== '') {
            $query->where('actor_id', (int) $this->filterActorId);
        }

        if ($this->filterDateFrom !== '') {
            $query->whereDate('created_at', '>=', $this->filterDateFrom);
        }

        if ($this->filterDateTo !== '') {
            $query->whereDate('created_at', '<=', $this->filterDateTo);
        }

        return [
            'logs' => $query->paginate(25),
            'actions' => AuditLog::query()->distinct()->orderBy('action')->pluck('action'),
            'actors' => User::query()->orderBy('name')->get(['id', 'name']),
        ];
    }

    public function formatEntity(?string $entityType, ?int $entityId): string
    {
        if (! $entityType || ! $entityId) {
            return '—';
        }

        $short = class_basename($entityType);

        return $short.' #'.$entityId;
    }

    public function formatChanges(?array $oldValues, ?array $newValues): string
    {
        if ($oldValues === null && $newValues === null) {
            return '—';
        }

        $payload = json_encode([
            'old' => $oldValues,
            'new' => $newValues,
        ], JSON_UNESCAPED_UNICODE);

        if (mb_strlen($payload) > 120) {
            return mb_substr($payload, 0, 117).'...';
        }

        return $payload;
    }

    public function formatChangesTitle(?array $oldValues, ?array $newValues): string
    {
        if ($oldValues === null && $newValues === null) {
            return '';
        }

        return json_encode([
            'old' => $oldValues,
            'new' => $newValues,
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
}; ?>

<div class="space-y-4">
    <x-card padding="p-4">
        <div class="flex flex-wrap items-end gap-3">
            <div class="min-w-[140px] flex-1">
                <x-input-label :value="__('Action')" class="text-xs" />
                <select wire:model.live="filterAction" class="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                    <option value="">{{ __('All actions') }}</option>
                    @foreach ($actions as $action)
                        <option value="{{ $action }}">{{ $action }}</option>
                    @endforeach
                </select>
            </div>
            <div class="min-w-[140px] flex-1">
                <x-input-label :value="__('Actor')" class="text-xs" />
                <select wire:model.live="filterActorId" class="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                    <option value="">{{ __('All actors') }}</option>
                    @foreach ($actors as $actor)
                        <option value="{{ $actor->id }}">{{ $actor->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="min-w-[130px]">
                <x-input-label :value="__('Date from')" class="text-xs" />
                <x-text-input wire:model.live="filterDateFrom" type="date" class="w-full mt-1" />
            </div>
            <div class="min-w-[130px]">
                <x-input-label :value="__('Date to')" class="text-xs" />
                <x-text-input wire:model.live="filterDateTo" type="date" class="w-full mt-1" />
            </div>
        </div>
    </x-card>

    <x-card padding="p-0" class="overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-100 text-sm">
                <thead class="bg-gray-50/80">
                    <tr>
                        <th class="px-4 py-2.5 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{{ __('Date') }}</th>
                        <th class="px-4 py-2.5 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{{ __('Actor') }}</th>
                        <th class="px-4 py-2.5 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{{ __('Action') }}</th>
                        <th class="px-4 py-2.5 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{{ __('Entity') }}</th>
                        <th class="px-4 py-2.5 text-left text-xs font-medium text-gray-500 uppercase tracking-wide">{{ __('Changes') }}</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse ($logs as $log)
                        <tr class="hover:bg-gray-50/80 transition-colors">
                            <td class="px-4 py-2.5 whitespace-nowrap text-gray-700">{{ $log->created_at?->format('d.m.Y H:i') }}</td>
                            <td class="px-4 py-2.5 text-gray-800">{{ $log->actor?->name ?? __('System') }}</td>
                            <td class="px-4 py-2.5 font-mono text-xs text-gray-700">{{ $log->action }}</td>
                            <td class="px-4 py-2.5 text-gray-700">{{ $this->formatEntity($log->entity_type, $log->entity_id) }}</td>
                            <td class="px-4 py-2.5 font-mono text-xs text-gray-600 max-w-xs truncate" title="{{ $this->formatChangesTitle($log->old_values, $log->new_values) }}">
                                {{ $this->formatChanges($log->old_values, $log->new_values) }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-4 py-2.5">
                                <x-empty-state>{{ __('No audit entries yet.') }}</x-empty-state>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if ($logs->hasPages())
            <div class="px-4 py-2.5 border-t border-gray-100">
                {{ $logs->links() }}
            </div>
        @endif
    </x-card>
</div>
