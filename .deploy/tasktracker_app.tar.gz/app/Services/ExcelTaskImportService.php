<?php

namespace App\Services;

use App\Enums\AuthProvider;
use App\Enums\SystemType;
use App\Enums\TaskStatus;
use App\Models\Category;
use App\Models\Department;
use App\Models\Task;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

class ExcelTaskImportService
{
    private User $fallbackUser;

    private Department $itDepartment;

    /** @var array<string, User> */
    private array $initiatorCache = [];

    /** @var array<string, Department> */
    private array $departmentCache = [];

    /** @var array<string, Category> */
    private array $categoryCache = [];

    public function import(string $path, bool $dryRun = false): array
    {
        if (! is_readable($path)) {
            throw new \InvalidArgumentException("File not readable: {$path}");
        }

        $this->fallbackUser = User::query()
            ->where('email', config('tasktracker.admin_email'))
            ->firstOrFail();

        $this->itDepartment = Department::query()->where('name', 'IT')->firstOrFail();

        $sheet = IOFactory::load($path)->getSheetByName('Лист задач')
            ?? IOFactory::load($path)->getSheet(0);
        $imported = 0;
        $skipped = [];

        DB::transaction(function () use ($sheet, $dryRun, &$imported, &$skipped) {
            for ($row = 2; $row <= $sheet->getHighestRow(); $row++) {
                $numberRaw = trim((string) $sheet->getCell([1, $row])->getValue());
                $statusRaw = trim((string) $sheet->getCell([8, $row])->getValue());
                $description = trim((string) $sheet->getCell([5, $row])->getValue());

                if ($description === '' && $statusRaw === '') {
                    continue;
                }

                if (! $this->isActiveStatus($statusRaw)) {
                    continue;
                }

                if ($numberRaw === '' || ! is_numeric($numberRaw)) {
                    $skipped[] = ['row' => $row, 'reason' => 'missing_number', 'status' => $statusRaw];

                    continue;
                }

                $number = (int) $numberRaw;

                if (Task::query()->where('number', $number)->exists()) {
                    $skipped[] = ['row' => $row, 'number' => $number, 'reason' => 'already_exists'];

                    continue;
                }

                $status = $this->mapStatus($statusRaw);
                $initiatorDepartment = $this->mapDepartment(trim((string) $sheet->getCell([4, $row])->getValue()));
                $category = $this->mapCategory(trim((string) $sheet->getCell([6, $row])->getValue()));
                $initiator = $this->resolveInitiator(
                    trim((string) $sheet->getCell([3, $row])->getValue()),
                    $initiatorDepartment,
                );
                $assignee = $this->resolveAssignee();

                $deadline = $this->parseDate($sheet->getCell([7, $row])->getValue());
                $createdAt = $this->parseDate($sheet->getCell([2, $row])->getValue()) ?? now();
                $specUrl = $this->normalizeUrl($sheet->getCell([10, $row])->getValue());
                $resultUrl = $this->normalizeUrl($sheet->getCell([11, $row])->getValue());
                $title = $this->titleFromDescription($description);

                if ($dryRun) {
                    $imported++;

                    continue;
                }

                Task::create([
                    'number' => $number,
                    'initiator_id' => $initiator->id,
                    'assignee_id' => $assignee->id,
                    'department_initiator_id' => $initiatorDepartment->id,
                    'department_id' => $assignee->department_id,
                    'category_id' => $category->id,
                    'title' => $title,
                    'description' => $description,
                    'priority' => 5,
                    'status' => $status,
                    'deadline' => $deadline,
                    'spec_url' => $specUrl,
                    'result_url' => $resultUrl,
                    'review_due_at' => $status === TaskStatus::OnReview ? now()->addDays(3) : null,
                    'created_at' => $createdAt,
                    'updated_at' => $createdAt,
                ]);

                $imported++;
            }
        });

        return [
            'imported' => $imported,
            'skipped' => $skipped,
            'dry_run' => $dryRun,
        ];
    }

    private function isActiveStatus(string $status): bool
    {
        if ($status === '') {
            return false;
        }

        if (in_array($status, ['Отклонена', 'Отменена'], true)) {
            return false;
        }

        if (str_contains(mb_strtolower($status), 'выполнена')) {
            return false;
        }

        return true;
    }

    private function mapStatus(string $status): TaskStatus
    {
        return match (true) {
            str_contains($status, 'Ожидает данных') => TaskStatus::AwaitingInitiator,
            str_contains($status, 'В работе') => TaskStatus::InProgress,
            str_contains($status, 'проверка инициатором') => TaskStatus::OnReview,
            str_contains($status, 'На проверке') => TaskStatus::OnReview,
            str_contains($status, 'Отложена') => TaskStatus::Postponed,
            default => TaskStatus::New,
        };
    }

    private function mapDepartment(string $name): Department
    {
        $normalized = match ($name) {
            'Финансовый отедл' => 'Финансовый отдел',
            'маркетинг', 'Маркетинг', 'Отдел маркетинга' => 'Отдел маркетинга',
            'продажи', 'Продажи', 'Отдел продаж' => 'Отдел продаж',
            'Операционный', 'Операционный отдел' => 'Операционный отдел',
            'Учебный отдел' => 'Учебный отдел',
            'IT', 'ИТ' => 'IT',
            default => $name,
        };

        if (isset($this->departmentCache[$normalized])) {
            return $this->departmentCache[$normalized];
        }

        $dept = Department::query()->where('name', $normalized)->first()
            ?? Department::query()->where('name', 'IT')->firstOrFail();

        return $this->departmentCache[$normalized] = $dept;
    }

    private function mapCategory(string $name): Category
    {
        if (isset($this->categoryCache[$name])) {
            return $this->categoryCache[$name];
        }

        $cat = Category::query()->where('name', $name)->first()
            ?? Category::query()->where('name', 'Прочие задачи')->firstOrFail();

        return $this->categoryCache[$name] = $cat;
    }

    private function resolveInitiator(string $label, Department $initiatorDepartment): User
    {
        if ($label === '') {
            return $this->fallbackUser;
        }

        $cacheKey = $label.'|'.$initiatorDepartment->id;
        if (isset($this->initiatorCache[$cacheKey])) {
            return $this->initiatorCache[$cacheKey];
        }

        $slug = Str::slug(Str::replace(['@', ' '], ['', '-'], $label));
        if ($slug === '') {
            $slug = 'unknown-'.substr(md5($label), 0, 8);
        }

        $email = "import.{$slug}@tcsavant.com";

        $user = User::query()->firstOrCreate(
            ['email' => $email],
            [
                'name' => $label,
                'password' => Hash::make(Str::random(32)),
                'email_verified_at' => now(),
                'system_type' => SystemType::User,
                'auth_provider' => AuthProvider::Password,
                'department_id' => $initiatorDepartment->id,
                'locale' => 'ru',
                'is_active' => true,
            ]
        );

        if ($user->department_id !== $initiatorDepartment->id) {
            $user->update(['department_id' => $initiatorDepartment->id]);
        }

        return $this->initiatorCache[$cacheKey] = $user;
    }

    private function resolveAssignee(): User
    {
        if ($this->itDepartment->head_user_id) {
            $head = User::query()->where('is_active', true)->find($this->itDepartment->head_user_id);
            if ($head) {
                return $head;
            }
        }

        return $this->fallbackUser;
    }

    private function parseDate(mixed $value): ?Carbon
    {
        if ($value === null || $value === '') {
            return null;
        }

        if (is_numeric($value)) {
            return Carbon::instance(ExcelDate::excelToDateTimeObject((float) $value))
                ->timezone(config('app.timezone'));
        }

        try {
            return Carbon::parse((string) $value, config('app.timezone'));
        } catch (\Throwable) {
            return null;
        }
    }

    private function normalizeUrl(mixed $value): ?string
    {
        $url = trim((string) $value);

        return filter_var($url, FILTER_VALIDATE_URL) ? $url : null;
    }

    private function titleFromDescription(string $description): string
    {
        $normalized = trim(preg_replace('/\s+/', ' ', $description) ?? '');

        return Str::limit($normalized, 120, '');
    }
}
