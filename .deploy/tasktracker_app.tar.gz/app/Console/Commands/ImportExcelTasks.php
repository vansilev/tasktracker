<?php

namespace App\Console\Commands;

use App\Services\ExcelTaskImportService;
use Illuminate\Console\Command;

class ImportExcelTasks extends Command
{
    protected $signature = 'tasks:import-excel {path : Path to the Excel file} {--dry-run : Analyze without writing}';

    protected $description = 'Import active tasks from IT Task Tracker Excel file';

    public function handle(ExcelTaskImportService $importer): int
    {
        $path = $this->argument('path');

        if (! file_exists($path)) {
            $this->error("File not found: {$path}");

            return self::FAILURE;
        }

        $dryRun = (bool) $this->option('dry-run');

        if ($dryRun) {
            $this->warn('Dry run — no rows will be written.');
        }

        $result = $importer->import($path, $dryRun);

        $this->info(($dryRun ? 'Would import' : 'Imported').": {$result['imported']} tasks");

        if ($result['skipped'] !== []) {
            $this->warn('Skipped '.count($result['skipped']).' rows:');
            foreach ($result['skipped'] as $skip) {
                $this->line('  '.json_encode($skip, JSON_UNESCAPED_UNICODE));
            }
        }

        if (! $dryRun) {
            $this->info('Total tasks in DB: '.\App\Models\Task::count());
            $this->info('Max task number: '.\App\Models\Task::max('number'));
        }

        return self::SUCCESS;
    }
}
