<?php

namespace App\Http\Controllers;

use App\Models\TaskAttachment;
use App\Services\TaskAttachmentService;
use Illuminate\Support\Facades\Response;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class TaskAttachmentController extends Controller
{
    public function download(TaskAttachment $attachment, TaskAttachmentService $attachments): BinaryFileResponse
    {
        $path = $attachments->downloadPath($attachment, auth()->user());

        return Response::download($path, $attachment->filename, [
            'Content-Type' => $attachment->mime,
        ]);
    }
}
